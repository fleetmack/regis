/*** This passes in an entire record to the entity table using the ROWTYPE instead of passing in ***/
/*** Individual Parameters ***/
CREATE OR REPLACE PACKAGE macks_stuff IS
FUNCTION mack_count_records
	(field_name_m1 IN VARCHAR2)
	RETURN NUMBER;
PROCEDURE mack_update_entity_table
(entity_in IN entity%rowtype);
PROCEDURE mack_delete_entity_rec
(id_number_mi2 IN NUMBER);
END;
/

CREATE OR REPLACE PACKAGE BODY macks_stuff IS
FUNCTION mack_count_records
	(field_name_m1 IN VARCHAR2)
	RETURN NUMBER
IS
	hold_count_m1 NUMBER(3);
BEGIN
SELECT distinct(count(field_name_m1))
  INTO hold_count_m1
  FROM entity;
  RETURN hold_count_m1;
 END mack_count_records;
PROCEDURE mack_update_entity_table
(entity_in IN entity%rowtype)
IS
	BEGIN
	INSERT INTO entity (id_number, first_name, last_name, gender)
	VALUES (entity_in.id_number, entity_in.first_name, entity_in.last_name, entity_in.gender);
	DBMS_OUTPUT.PUT_LINE('New Record Inserted Into Entity Table');
END mack_update_entity_table;
PROCEDURE mack_delete_entity_rec
(id_number_mi2 IN NUMBER)
IS
	fk_bad_4	EXCEPTION;
	PRAGMA EXCEPTION_INIT(fk_bad_4, -2292);
BEGIN
	DELETE FROM entity
	WHERE id_number = id_number_mi2;
	DBMS_OUTPUT.PUT_LINE('Record Deleted');
EXCEPTION WHEN NO_DATA_FOUND THEN DBMS_OUTPUT.PUT_LINE('That Id does not exist');
 WHEN fk_bad_4 THEN DBMS_OUTPUT.PUT_LINE('That Record is a primary key which exists In Other tables, cannot delete');
END mack_delete_entity_rec;
END;
/


/*** This passes in an entire record to the cars table using the ROWTYPE instead of passing in ***/
/*** Individual Parameters ***/
CREATE OR REPLACE PACKAGE macks_stuff_2 IS
FUNCTION mack_count_cars
	(field_name_m2 IN VARCHAR2)
	RETURN NUMBER;
PROCEDURE mack_update_car_table
(cars_in IN cars%rowtype);
PROCEDURE mack_delete_car_rec
	(id_number_mi3 IN NUMBER);
END;
/


CREATE OR REPLACE PACKAGE BODY macks_stuff_2 IS
FUNCTION mack_count_cars
	(field_name_m2 IN VARCHAR2)
	RETURN NUMBER
IS	
	hold_count_m2 NUMBER(3);
BEGIN
	SELECT COUNT(field_name_m2)
	  INTO hold_count_m2
	  FROM cars;
	RETURN hold_count_m2;
END mack_count_cars;
PROCEDURE mack_update_car_table
(cars_in IN cars%rowtype)
IS
	BEGIN
	INSERT INTO cars(id_number, car_make, car_model, car_year, car_curr_value)
	VALUES(cars_in.id_number, cars_in.car_make, cars_in.car_model, cars_in.car_year, cars_in.car_curr_value);
	DBMS_OUTPUT.PUT_LINE('Car Table Record Inserted');
END mack_update_car_table;
PROCEDURE mack_delete_car_rec
	(id_number_mi3 IN NUMBER)
IS
	fk_bad5	EXCEPTION;
	PRAGMA EXCEPTION_INIT(fk_bad5, -2292);
BEGIN
	DELETE FROM cars
	WHERE id_number_mi3 = id_number;
	DBMS_OUTPUT.PUT_LINE('car deleted');
EXCEPTION WHEN NO_DATA_FOUND THEN DBMS_OUTPUT.PUT_LINE('That Id does not exist');
 WHEN fk_bad5 THEN DBMS_OUTPUT.PUT_LINE('That Record is a primary key which exists In Other tables, cannot delete');
END mack_delete_car_rec;
END;
/