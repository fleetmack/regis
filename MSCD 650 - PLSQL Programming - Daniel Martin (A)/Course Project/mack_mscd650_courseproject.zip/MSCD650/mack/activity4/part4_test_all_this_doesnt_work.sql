/*** NOTE: I simply cannot get this to work.  I have no idea how to get the rowtype ***/
/*** Procedure to execute.  This section does not work, sorry! You stumped me! ***/
SET SERVEROUTPUT ON
VARIABLE hold_count_records VARCHAR2(25)
VARIABLE hold_count_records2 VARCHAR2(25)
BEGIN
	:hold_count_records := macks_stuff.mack_count_records('id_number');
	:hold_count_records2 := macks_stuff_2.mack_count_cars('id_number');
	DBMS_OUTPUT.PUT_LINE('Total Entities: '||:hold_count_records);
	DBMS_OUTPUT.PUT_LINE('TOtal Cars: '||:hold_count_records2);
macks_stuff.mack_update_entity_table(13,'Jose','Guillen','M');
macks_stuff_2.mack_update_car_table(13,'Subaru','Outback','2008',25000);
	:hold_count_records := macks_stuff.count_records('id_number');
	:hold_count_records2 := macks_stuff_2.count_cars('id_number');
	DBMS_OUTPUT.PUT_LINE('Total Entities: '||:hold_count_records);
	DBMS_OUTPUT.PUT_LINE('TOtal Cars: '||:hold_count_records2);
macks_stuff_2.mack_delete_car_rec(13);
macks_stuff_2.mack_delete_entity_rec(13);



macks_stuff_2.mack_update_car_table(????);



	:hold_count_records := count_records('id_number');
	:hold_count_records2 := count_cars('id_number');
	DBMS_OUTPUT.PUT_LINE('Total Entities: '||:hold_count_records);
	DBMS_OUTPUT.PUT_LINE('TOtal Cars: '||:hold_count_records2);
END;
/
