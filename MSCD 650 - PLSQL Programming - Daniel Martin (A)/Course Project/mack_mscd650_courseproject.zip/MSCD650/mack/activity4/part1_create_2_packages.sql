CREATE OR REPLACE PACKAGE macks_stuff IS
FUNCTION mack_count_records
	(field_name_m1 IN VARCHAR2)
	RETURN NUMBER;
PROCEDURE mack_update_entity_table
(id_number_mi IN NUMBER,
 first_name_mi IN VARCHAR2,
 last_name_mi IN VARCHAR2,
 gender_mi    IN VARCHAR2);
PROCEDURE mack_delete_entity_rec
(id_number_mi2 IN NUMBER);
END;
/

CREATE OR REPLACE PACKAGE BODY macks_stuff IS
FUNCTION mack_count_records
	(field_name_m1 IN VARCHAR2)
	RETURN NUMBER
IS
	hold_count_m1 NUMBER(3);
BEGIN
SELECT distinct(count(field_name_m1))
  INTO hold_count_m1
  FROM entity;
  RETURN hold_count_m1;
 END mack_count_records;
PROCEDURE mack_update_entity_table
(id_number_mi IN NUMBER,
 first_name_mi IN VARCHAR2,
 last_name_mi IN VARCHAR2,
 gender_mi IN VARCHAR2)
IS
	BEGIN
	INSERT INTO entity (id_number, first_name, last_name, gender)
	VALUES (id_number_mi, first_name_mi, last_name_mi, gender_mi);
	DBMS_OUTPUT.PUT_LINE('New Record Inserted Into Entity Table');
END mack_update_entity_table;
PROCEDURE mack_delete_entity_rec
(id_number_mi2 IN NUMBER)
IS
	fk_bad_4	EXCEPTION;
	PRAGMA EXCEPTION_INIT(fk_bad_4, -2292);
BEGIN
	DELETE FROM entity
	WHERE id_number = id_number_mi2;
	DBMS_OUTPUT.PUT_LINE('Record Deleted');
EXCEPTION WHEN NO_DATA_FOUND THEN DBMS_OUTPUT.PUT_LINE('That Id does not exist');
 WHEN fk_bad_4 THEN DBMS_OUTPUT.PUT_LINE('That Record is a primary key which exists In Other tables, cannot delete');
END mack_delete_entity_rec;
END;
/



CREATE OR REPLACE PACKAGE macks_stuff_2 IS
FUNCTION mack_count_cars
	(field_name_m2 IN VARCHAR2)
	RETURN NUMBER;
PROCEDURE mack_update_car_table
(id_number_mi2 IN NUMBER,
 car_make_mi2 IN VARCHAR2,
 car_model_mi2 IN VARCHAR2,
 car_year_mi2 IN VARCHAR2,
 car_curr_value_mi2 IN VARCHAR2);
PROCEDURE mack_delete_car_rec
	(id_number_mi3 IN NUMBER);
END;
/


CREATE OR REPLACE PACKAGE BODY macks_stuff_2 IS
FUNCTION mack_count_cars
	(field_name_m2 IN VARCHAR2)
	RETURN NUMBER
IS	
	hold_count_m2 NUMBER(3);
BEGIN
	SELECT COUNT(field_name_m2)
	  INTO hold_count_m2
	  FROM cars;
	RETURN hold_count_m2;
END mack_count_cars;
PROCEDURE mack_update_car_table
(id_number_mi2 IN NUMBER,
 car_make_mi2 IN VARCHAR2,
 car_model_mi2 IN VARCHAR2,
 car_year_mi2 IN VARCHAR2,
 car_curr_value_mi2 IN VARCHAR2)
IS
	BEGIN
	INSERT INTO cars(id_number, car_make, car_model, car_year, car_curr_value)
	VALUES(id_number_mi2, car_make_mi2, car_model_mi2, car_year_mi2, car_curr_value_mi2);
	DBMS_OUTPUT.PUT_LINE('Car Table Record Inserted');
END mack_update_car_table;
PROCEDURE mack_delete_car_rec
	(id_number_mi3 IN NUMBER)
IS
	fk_bad5	EXCEPTION;
	PRAGMA EXCEPTION_INIT(fk_bad5, -2292);
BEGIN
	DELETE FROM cars
	WHERE id_number_mi3 = id_number;
	DBMS_OUTPUT.PUT_LINE('car deleted');
EXCEPTION WHEN NO_DATA_FOUND THEN DBMS_OUTPUT.PUT_LINE('That Id does not exist');
 WHEN fk_bad5 THEN DBMS_OUTPUT.PUT_LINE('That Record is a primary key which exists In Other tables, cannot delete');
END mack_delete_car_rec;
END;
/
