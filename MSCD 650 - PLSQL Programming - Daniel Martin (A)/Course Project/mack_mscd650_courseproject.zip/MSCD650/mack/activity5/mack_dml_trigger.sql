CREATE OR REPLACE TRIGGER mack_audit_trg
AFTER UPDATE OR DELETE ON entity
FOR EACH ROW
DECLARE
trg_id_number	VARCHAR2(20);
action		VARCHAR2(20);
update_id	VARCHAR2(20);
BEGIN
IF UPDATING THEN action := 'UPDATE';
ELSIF DELETING THEN action := 'DELETE';
END IF;
INSERT INTO mack_audit (audit_id, dml_type, id_updated, date_of_record)
	VALUES(audit_pk.nextval, action , :NEW.id_number, sysdate);
END;
/