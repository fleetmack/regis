/*** Note: I still cannot get my rowtype procedures to execute from number 4 ***/
/*** I will manually run the insert, update, and delete in order to prove that ***/
/*** My audit table works ***/
SET SERVEROUTPUT ON
SET LINESIZE 1000
BEGIN
INSERT INTO entity VALUES (27, 'Alex','Gordon','M');
UPDATE entity SET first_name = 'Alexander' WHERE id_number = 27;
DELETE FROM entity WHERE id_number = 27;
END;
/
SELECT * FROM mack_audit;