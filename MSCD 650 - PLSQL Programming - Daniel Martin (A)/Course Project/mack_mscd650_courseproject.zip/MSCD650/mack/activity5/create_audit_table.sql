/*** (DROP AND) create my audit table ***/
DROP TABLE mack_audit;
DROP SEQUENCE audit_pk;
COMMIT;

CREATE SEQUENCE audit_pk
START WITH 1
INCREMENT BY 1;
COMMIT;



CREATE TABLE mack_audit
	(audit_id		NUMBER(10) PRIMARY KEY NOT NULL,
	 dml_type		VARCHAR2(30),
	id_updated		VARCHAR2(30),
	 date_of_record		DATE);
COMMIT;
