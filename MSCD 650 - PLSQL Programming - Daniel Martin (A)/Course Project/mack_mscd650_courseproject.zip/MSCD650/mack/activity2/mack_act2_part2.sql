/*** This procedure will insert the number of dates I've gone on with each female in the database ***/
/*** The records will be read in from the entity table, and the dates will be stored in dates_with_bryan table ***/
DECLARE
hold_id	NUMBER(10) := 1;
hold_gender VARCHAR2(1);
BEGIN
WHILE hold_id <= 10
LOOP
SELECT gender
INTO hold_gender
FROM entity
WHERE id_number = hold_id;
IF hold_gender = 'F' AND hold_id <> 0000000002 THEN 
	INSERT INTO dates_with_bryan VALUES (hold_id, 0);
ELSIF hold_gender = 'F' AND hold_id = 0000000002 THEN
	INSERT INTO dates_with_bryan VALUES (hold_id, 250);
END IF;
hold_id := hold_id + 1;
END LOOP;
END;
/