SET SERVEROUTPUT ON
/*** This anonymous block will depreciate the value of the cars by 10 percent ***/
DECLARE
year	varchar2(4);
value	number(8,2);
id_hold	number(2) := 1;
BEGIN
WHILE id_hold <= 10
LOOP
SELECT car_year, car_curr_value
INTO year, value
FROM cars
WHERE id_number = id_hold;
UPDATE cars
   SET car_curr_value = car_curr_value * (.9)
 WHERE id_number = id_hold;
DBMS_OUTPUT.PUT_LINE('Car belonging to id Number '||id_hold||' has had value reduced by 10%');
id_hold := id_hold + 1;
END LOOP;
END;
/