/*** This procedure deletes a record in the entity table ***/
/*** If the entity to be deleted exists in other tables where it is a foreign key, an exception is raised ***/
/*** If the value doesn't exist in the table, an exception is raised ***/
CREATE OR REPLACE PROCEDURE delete_entity_rec
(id_number_i IN NUMBER)
IS
	fk_bad		EXCEPTION;
	PRAGMA EXCEPTION_INIT(fk_bad, -2292);
BEGIN
	DELETE FROM entity
	WHERE id_number = id_number_i;
	DBMS_OUTPUT.PUT_LINE('Record Deleted');
EXCEPTION WHEN NO_DATA_FOUND THEN DBMS_OUTPUT.PUT_LINE('That Id does not exist');
 WHEN fk_bad THEN DBMS_OUTPUT.PUT_LINE('That Record is a primary key which exists In Other tables, cannot delete');
END;
/


/*** This procedure will delete a record from a detail table ***/
CREATE OR REPLACE PROCEDURE delete_car_rec
(id_number_i IN NUMBER)
IS
	fk_bad2		EXCEPTION;
	PRAGMA EXCEPTION_INIT(fk_bad2, -2292);
BEGIN
	DELETE FROM cars
	WHERE id_number_i = id_number;
	DBMS_OUTPUT.PUT_LINE('Car Deleted');
EXCEPTION WHEN NO_DATA_FOUND THEN DBMS_OUTPUT.PUT_LINE('That Id does not exist');
 WHEN fk_bad2 THEN DBMS_OUTPUT.PUT_LINE('That Record is a primary key which exists In Other tables, cannot delete');
END;
/
