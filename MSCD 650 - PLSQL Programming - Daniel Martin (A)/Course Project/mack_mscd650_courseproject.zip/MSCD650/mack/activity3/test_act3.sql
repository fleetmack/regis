SET SERVEROUTPUT ON
VARIABLE hold_count_records VARCHAR2(25)
VARIABLE hold_count_records2 VARCHAR2(25)
BEGIN
	:hold_count_records := count_records('id_number');
	:hold_count_records2 := count_cars('id_number');
	DBMS_OUTPUT.PUT_LINE('Total Entities: '||:hold_count_records);
	DBMS_OUTPUT.PUT_LINE('TOtal Cars: '||:hold_count_records2);
update_entity_table(13,'Jose','Guillen','M');
update_car_table(13,'Subaru','Outback','2008',25000);
	:hold_count_records := count_records('id_number');
	:hold_count_records2 := count_cars('id_number');
	DBMS_OUTPUT.PUT_LINE('Total Entities: '||:hold_count_records);
	DBMS_OUTPUT.PUT_LINE('TOtal Cars: '||:hold_count_records2);
delete_car_rec(13);
delete_entity_rec(13);
	:hold_count_records := count_records('id_number');
	:hold_count_records2 := count_cars('id_number');
	DBMS_OUTPUT.PUT_LINE('Total Entities: '||:hold_count_records);
	DBMS_OUTPUT.PUT_LINE('TOtal Cars: '||:hold_count_records2);
END;
/


