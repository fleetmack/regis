/*** Type in a field name of a field which exists ***/
/*** in the entity table and this will give you ***/
/*** a count of how many of those rows exist ***/
create or replace function count_records
(field_name IN VARCHAR2)
RETURN NUMBER
IS
	hold_count number(3);
BEGIN
select distinct(count(field_name))
into hold_count
from entity;
return hold_count;
end;
/


VARIABLE hold_count_records VARCHAR2(25)
BEGIN
	:hold_count_records := count_records('id_number');
	DBMS_OUTPUT.PUT_LINE(:hold_count_records);
END;
/


/*** Type in a field name of a field which exists ***/
/*** in the entity table and this will give you ***/
/*** a count of how many of those rows exist ***/
create or replace function count_cars
(field_name2 IN VARCHAR2)
RETURN NUMBER
IS
	hold_count_g number(3);
BEGIN
select count(field_name2)
into hold_count_g
from cars;
return hold_count_g;
end;
/

