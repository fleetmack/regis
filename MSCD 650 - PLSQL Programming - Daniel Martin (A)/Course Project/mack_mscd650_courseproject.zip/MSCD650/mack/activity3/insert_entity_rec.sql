/*** This Procedure Will Enter A NEw Record Into the Entity Table ***/
CREATE OR REPLACE PROCEDURE update_entity_table
(id_number_i IN NUMBER,
 first_name_i IN VARCHAR2,
 last_name_i IN VARCHAR2,
 gender_i	IN VARCHAR2)
IS
	BEGIN
	INSERT INTO entity (id_number, first_name, last_name, gender)
	VALUES (id_number_i, first_name_i, last_name_i, gender_i);
	DBMS_OUTPUT.PUT_LINE('New Record Inserted Into Entity Table');
	END;
/


/*** This Procedure Will Enter A New Record Into The Car Table ***/
CREATE OR REPLACE PROCEDURE update_car_table
(id_number_in IN NUMBER,
 car_make_in IN VARCHAR2,
 car_model_in IN VARCHAR2,
 car_year_in IN VARCHAR2,
 car_curr_value_in VARCHAR2)
IS
	BEGIN
	INSERT INTO cars(id_number, car_make, car_model, car_year, car_curr_value)
	VALUES (id_number_in, car_make_in, car_model_in, car_year_in, car_curr_value_in);
	DBMS_OUTPUT.PUT_LINE('Car Table Record Inserted');
	END;
/

