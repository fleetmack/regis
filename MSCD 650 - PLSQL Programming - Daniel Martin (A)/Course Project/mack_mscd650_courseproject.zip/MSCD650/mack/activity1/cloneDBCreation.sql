connect "SYS"/"&&sysPassword" as SYSDBA
set echo on
spool C:\MSCD650\mack\activity1\cloneDBCreation.log
Create controlfile reuse set database "mscd650p"
MAXINSTANCES 8
MAXLOGHISTORY 1
MAXLOGFILES 16
MAXLOGMEMBERS 3
MAXDATAFILES 100
Datafile 
'C:\oracle\product\10.2.0\oradata\mscd650project\SYSTEM01.DBF',
'C:\oracle\product\10.2.0\oradata\mscd650project\UNDOTBS01.DBF',
'C:\oracle\product\10.2.0\oradata\mscd650project\SYSAUX01.DBF',
'C:\oracle\product\10.2.0\oradata\mscd650project\USERS01.DBF'
LOGFILE GROUP 1 ('C:\oracle\product\10.2.0/oradata/mscd650project/redo01.log') SIZE 51200K,
GROUP 2 ('C:\oracle\product\10.2.0/oradata/mscd650project/redo02.log') SIZE 51200K,
GROUP 3 ('C:\oracle\product\10.2.0/oradata/mscd650project/redo03.log') SIZE 51200K RESETLOGS;
exec dbms_backup_restore.zerodbid(0);
shutdown immediate;
startup nomount pfile="C:\MSCD650\mack\activity1\initmscd650projectTemp.ora";
Create controlfile reuse set database "mscd650p"
MAXINSTANCES 8
MAXLOGHISTORY 1
MAXLOGFILES 16
MAXLOGMEMBERS 3
MAXDATAFILES 100
Datafile 
'C:\oracle\product\10.2.0\oradata\mscd650project\SYSTEM01.DBF',
'C:\oracle\product\10.2.0\oradata\mscd650project\UNDOTBS01.DBF',
'C:\oracle\product\10.2.0\oradata\mscd650project\SYSAUX01.DBF',
'C:\oracle\product\10.2.0\oradata\mscd650project\USERS01.DBF'
LOGFILE GROUP 1 ('C:\oracle\product\10.2.0/oradata/mscd650project/redo01.log') SIZE 51200K,
GROUP 2 ('C:\oracle\product\10.2.0/oradata/mscd650project/redo02.log') SIZE 51200K,
GROUP 3 ('C:\oracle\product\10.2.0/oradata/mscd650project/redo03.log') SIZE 51200K RESETLOGS;
alter system enable restricted session;
alter database "mscd650p" open resetlogs;
alter database rename global_name to "mscd650p";
ALTER TABLESPACE TEMP ADD TEMPFILE 'C:\oracle\product\10.2.0\oradata\mscd650project\TEMP01.DBF' SIZE 20480K REUSE AUTOEXTEND ON NEXT 640K MAXSIZE UNLIMITED;
select tablespace_name from dba_tablespaces where tablespace_name='USERS';
select sid, program, serial#, username from v$session;
alter database character set INTERNAL_CONVERT WE8MSWIN1252;
alter database national character set INTERNAL_CONVERT AL16UTF16;
alter user sys identified by "&&sysPassword";
alter user system identified by "&&systemPassword";
alter system disable restricted session;
