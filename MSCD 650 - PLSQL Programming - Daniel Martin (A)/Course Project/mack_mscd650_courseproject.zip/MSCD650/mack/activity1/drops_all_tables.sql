/*** This script drops all tables in the database ***/
/*** to recreate run the create_all_tables.sql file ***/
drop table address;
drop table cars;
drop table dates_with_bryan;
drop table entity;