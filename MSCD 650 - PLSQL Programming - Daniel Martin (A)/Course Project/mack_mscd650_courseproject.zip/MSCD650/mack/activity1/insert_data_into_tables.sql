INSERT INTO entity VALUES (0000000001, 'Bryan', 'Mack', 'M');
INSERT INTO entity VALUES (0000000002, 'Fabienne', 'Buechel', 'F');
INSERT INTO entity VALUES (0000000003, 'Bret','Saberhagen','M');
INSERT INTO entity VALUES (0000000004, 'Corey','Taylor','M');
INSERT INTO entity VALUES (0000000005, 'Penelope','Cruz','F');
INSERT INTO entity VALUES (0000000006, 'Mike','Holmgren','M');
INSERT INTO entity VALUES (0000000007, 'Steve','Brule','M');
INSERT INTO entity VALUES (0000000008, 'Laetitia','Casta','F');
INSERT INTO entity VALUES (0000000009, 'Tara','Dakides','F');
INSERT INTO entity VALUES (0000000010, 'Cataline','Stone','F');


INSERT INTO address VALUES (0000000001,'9545 W. Coal Mine Ave.','Unit L','Littleton','CO','80123','2254','303','521','8275');
INSERT INTO address VALUES (0000000002,'9545 W. Coal Mine Ave.','Unit L','Littleton','CO','80123','2254','720','991','3386');
INSERT INTO address VALUES (0000000003, '123 Awesome Pitcher St.',null, 'Kansas City','MO','64557','1144','816','555','5544');
INSERT INTO address VALUES (0000000004, '234 Slipknot Ave.', null, 'Des Moines','IA','50210','4444','515','294','1234');
INSERT INTO address VALUES (0000000005, '443 Gorgeous Woman Dr.','Penthouse','Los Angelas','CA','90754','4567','818','123','4567');
INSERT INTO address VALUES (0000000006, '443 Seahawks Way',null,'Seattle','WA','99874','4567','555','557','7776');
INSERT INTO address VALUES (0000000007, '8472 Puzzle Blvd.', 'Apt. 321','Napa Valley','CA','94875','1111','987','654','3210');
INSERT INTO address VALUES (0000000008, '73 In My Dreams','Dream# 23','New York City','NY','10101','2222','910','247','4537');
INSERT INTO address VALUES (0000000009, '277 Snowboard Lane','#2B','Carlsbad','CA','97845','1278','619','457','2348');
INSERT INTO address VALUES (0000000010, '234 Main St.', 'Paleantology Dept.','San Diego','CA','97842','3245','619','654','6575');

INSERT INTO cars VALUES (0000000001, 'Honda','Accord LX','1995',2000);
INSERT INTO cars VALUES (0000000002, 'Skoda','Fabia', '2005',7500);
INSERT INTO cars VALUES (0000000003, 'Nissan','Maxima','2008',24000.23);
INSERT INTO cars VALUES (0000000004, 'Cadillac','Escalade','2003',29000);
INSERT INTO cars VALUES (0000000005, 'Porsche','Boxter','2006',68000);
INSERT INTO cars VALUES (0000000006, 'Ford','F250','2006',38000);
INSERT INTO cars VALUES (0000000007, 'Dodge','Aries','1983', 500);
INSERT INTO cars VALUES (0000000008, 'BMW','740i','2008',84000);
INSERT INTO cars VALUES (0000000009, 'Dodge','Ram','2002',23000);
INSERT INTO cars VALUES (0000000010, 'Hummer','H2',2002, 33000);