CREATE TABLE entity
(id_number	NUMBER(10) NOT NULL,
 first_name	VARCHAR2(20),
 last_name	VARCHAR2(20),
 gender		CHAR(1),
CONSTRAINT id_number_pk PRIMARY KEY(id_numbeR));
COMMIT;

CREATE TABLE address
(id_number	NUMBER(10) NOT NULL,
 street1	VARCHAR2(30),
 street2	VARCHAR2(30),
 city		VARCHAR2(30),
 state_code	CHAR(2),
 zip5		CHAR(5),
 zip4		CHAR(4),
 ph_area_code   VARCHAR2(3),
 ph_prefix	VARCHAR2(3),
 ph_number	VARCHAR2(4),
CONSTRAINT fk_id FOREIGN KEY(id_number) REFERENCES entity(id_number));
COMMIT;

CREATE TABLE cars
(id_number	NUMBER(10) NOT NULL,
 car_make	VARCHAR2(15),
 car_model	VARCHAR2(15),
 car_year	VARCHAR2(4),
 car_curr_value NUMBER(8,2),
CONSTRAINT fk_id2 FOREIGN KEY(id_number) REFERENCES entity(id_number));
COMMIT;

CREATE TABLE dates_with_bryan
(id_number	NUMBER(10) NOT NULL,
num_of_dates	NUMBER(4),
CONSTRAINT fk_id3 FOREIGN KEY(id_number) REFERENCES entity(id_number));
COMMIT;