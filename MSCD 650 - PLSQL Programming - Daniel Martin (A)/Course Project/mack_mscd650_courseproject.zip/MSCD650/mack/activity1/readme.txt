If you want to create a new instance, there are the scripts there to run to create it.  Simply running
mscd650project.bat will create the oracle instance.

In order to create the tables to place in a schema, run the create_all_tables.sql file.

To insert data into the tables, run the create_all_tables.sql script.

To truncate the tables (in order to remove the data) simply run the truncate_tables.sql file.