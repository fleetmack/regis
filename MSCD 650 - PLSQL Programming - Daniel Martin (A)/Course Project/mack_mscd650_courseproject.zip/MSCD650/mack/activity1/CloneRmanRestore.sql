connect "SYS"/"&&sysPassword" as SYSDBA
set echo on
spool C:\MSCD650\mack\activity1\CloneRmanRestore.log
startup nomount pfile="C:\MSCD650\mack\activity1\init.ora";
@C:\MSCD650\mack\activity1\rmanRestoreDatafiles.sql;
