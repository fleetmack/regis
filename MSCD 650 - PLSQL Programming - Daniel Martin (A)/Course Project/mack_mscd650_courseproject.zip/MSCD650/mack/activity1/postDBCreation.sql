connect "SYS"/"&&sysPassword" as SYSDBA
set echo on
spool C:\MSCD650\mack\activity1\postDBCreation.log
connect "SYS"/"&&sysPassword" as SYSDBA
set echo on
create spfile='C:\oracle\product\10.2.0\db_2/dbs/spfilemscd650project.ora' FROM pfile='C:\MSCD650\mack\activity1\init.ora';
shutdown immediate;
connect "SYS"/"&&sysPassword" as SYSDBA
startup ;
alter user SYSMAN identified by "&&sysmanPassword" account unlock;
alter user DBSNMP identified by "&&dbsnmpPassword" account unlock;
select 'utl_recomp_begin: ' || to_char(sysdate, 'HH:MI:SS') from dual;
execute utl_recomp.recomp_serial();
select 'utl_recomp_end: ' || to_char(sysdate, 'HH:MI:SS') from dual;
host C:\oracle\product\10.2.0\db_2\bin\emca.bat -config dbcontrol db -silent -DB_UNIQUE_NAME mscd650project -PORT 1521 -EM_HOME C:\oracle\product\10.2.0\db_2 -LISTENER LISTENER -SERVICE_NAME mscd650project -SYS_PWD &&sysPassword -SID mscd650project -ORACLE_HOME C:\oracle\product\10.2.0\db_2 -DBSNMP_PWD &&dbsnmpPassword -HOST localhost -LISTENER_OH C:\oracle\product\10.2.0\db_2 -LOG_FILE C:\MSCD650\mack\activity1\emConfig.log -SYSMAN_PWD &&sysmanPassword;
spool C:\MSCD650\mack\activity1\postDBCreation.log
